package com.meghana.passportmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassportmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
