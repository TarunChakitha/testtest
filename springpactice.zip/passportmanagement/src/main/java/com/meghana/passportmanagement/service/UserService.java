package com.meghana.passportmanagement.service;

public interface UserService {

}
