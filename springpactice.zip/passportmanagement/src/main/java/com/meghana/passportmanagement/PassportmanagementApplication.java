package com.meghana.passportmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PassportmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(PassportmanagementApplication.class, args);
		System.out.println("App Started...");
	}

}
