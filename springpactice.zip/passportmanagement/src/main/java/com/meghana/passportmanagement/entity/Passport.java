package com.meghana.passportmanagement.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.sun.istack.NotNull;

@Entity
public class Passport {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int passportId;

	@NotNull
	private String passportNumber;

	@OneToOne
	@NotNull
	private User user;

	public Passport() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Passport(int passportId, String passportNumber, User user) {
		super();
		this.passportId = passportId;
		this.passportNumber = passportNumber;
		this.user = user;
	}

	public int getPassportId() {
		return passportId;
	}

	public void setPassportId(int passportId) {
		this.passportId = passportId;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

}
