package com.meghana.passportmanagement.service.impl;

import org.springframework.stereotype.Service;

import com.meghana.passportmanagement.service.UserService;

@Service
public class UserServiceImpl implements UserService {

}
