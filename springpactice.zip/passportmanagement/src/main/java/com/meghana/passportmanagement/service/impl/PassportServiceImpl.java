package com.meghana.passportmanagement.service.impl;

import org.springframework.stereotype.Service;

import com.meghana.passportmanagement.service.PassportService;

@Service
public class PassportServiceImpl implements PassportService {

}
