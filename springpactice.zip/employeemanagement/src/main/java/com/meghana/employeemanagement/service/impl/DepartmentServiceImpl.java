package com.meghana.employeemanagement.service.impl;

import org.springframework.stereotype.Service;

import com.meghana.employeemanagement.service.DepartmentService;

@Service
public class DepartmentServiceImpl implements DepartmentService {

}
