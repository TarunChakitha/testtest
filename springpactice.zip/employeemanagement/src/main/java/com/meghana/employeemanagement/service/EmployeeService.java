package com.meghana.employeemanagement.service;

public interface EmployeeService {

}
