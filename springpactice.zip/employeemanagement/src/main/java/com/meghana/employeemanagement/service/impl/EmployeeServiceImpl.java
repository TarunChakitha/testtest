package com.meghana.employeemanagement.service.impl;

import org.springframework.stereotype.Service;

import com.meghana.employeemanagement.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

}
