package com.meghana.employeemanagement.service;

public interface DepartmentService {

}
