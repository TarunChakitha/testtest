package com.meghana.simcardmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimcardmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
