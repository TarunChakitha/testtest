package com.meghana.simcardmanagement.service;

public interface SimCardService {

}
