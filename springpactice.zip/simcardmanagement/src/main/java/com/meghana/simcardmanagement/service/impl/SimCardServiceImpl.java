package com.meghana.simcardmanagement.service.impl;

import org.springframework.stereotype.Service;

@Service
public class SimCardServiceImpl {

}
