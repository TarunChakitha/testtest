package com.meghana.simcardmanagement.controller;

import org.springframework.stereotype.Controller;

@Controller
public class SimCardController {

}
