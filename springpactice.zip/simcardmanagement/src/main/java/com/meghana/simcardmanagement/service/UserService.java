package com.meghana.simcardmanagement.service;

public interface UserService {

}
